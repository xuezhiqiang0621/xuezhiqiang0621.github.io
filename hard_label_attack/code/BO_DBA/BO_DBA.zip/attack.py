
# -*- coding: gbk -*-
import argparse

import os
import random
import sys
import warnings
warnings.filterwarnings("ignore")

sys.path.append(os.getcwd())
from collections import defaultdict, OrderedDict
import json
from types import SimpleNamespace
import os.path as osp
import torch
import numpy as np
import glog as log
from torch.nn import functional as F
from config import CLASS_NUM, MODELS_TEST_STANDARD, IN_CHANNELS, IMAGE_DATA_ROOT, IMAGE_SIZE
from dataset.dataset_loader_maker import DataLoaderMaker
from models.standard_model import StandardModel
from models.defensive_model import DefensiveModel
from dataset.target_class_dataset import ImageNetDataset, CIFAR100Dataset, CIFAR10Dataset, TinyImageNetDataset
from utils.dataset_toolkit import select_random_image_of_target_class
from BO_DBA.python_files.Upsample import upsample_projection
from BO_DBA.python_files.Util import millis
import GPyOpt as gy
from tqdm import tqdm
import noise as ns
import cv2

class randomimg:
    def __init__(self, img, model, true_label, target_label=None):
        self.img = img
        self.model = model
        self.clip_min = 0
        self.clip_max = 1
        self.true_label = true_label
        self.target_label = target_label
        self.imagesize = img.size(-2)
        self.query = 0

    def decision(self, x):
        images = torch.clamp(x.permute(0, 3, 1, 2), min=self.clip_min, max=self.clip_max).cuda()
        logits = self.model(images)
        self.query += 1
        if self.target_label is None:
            return logits.max(1)[1] != self.true_label
        else:
            return logits.max(1)[1] == self.target_label

class preddifference:
    def __init__(self, image, dataset, maxnorm, noise, constraint='l2'):
        self.image = image
        self.dataset = dataset
        self.maxnorm = maxnorm
        self.noise = noise
        self.imagesize = image.imagesize
        self.best = self.imagesize * self.imagesize
        self.theta = 0.01
        self.adv = None
        self.constraint = constraint
        pass

    def func(self, parameters):
        # print(parameters)
        final = self.create_distorted_image(self.image.img, self.noise, self.maxnorm / 255, parameters)
        # print(final.shape)
        out, dist = self.binary_search(final, self.image, self.theta, l=self.constraint)
        print('Query:{}, dist:{}'.format(self.image.query, dist))
        # print(out.shape)
        if dist < self.best:
            self.best = dist
            self.adv = out
        return dist  # np.log(dist*(255/self.maxnorm))

    def binary_search(self, perturbed_image, imgobj, theta, l='l2'):
        low = 0
        while imgobj.decision(perturbed_image) == 0:
            lowimage = perturbed_image
            perturbed_image = (perturbed_image - imgobj.img) * 2 + imgobj.img
            perturbed_image = np.clip(perturbed_image, 0, 1)
            if np.array_equal(lowimage, perturbed_image):
                print('inf happened')
                if l == 'l2':
                    return perturbed_image, self.imagesize * self.imagesize
                else:
                    return perturbed_image, 1.0
            #        display_images(perturbed_image)
            low = 0
        high = 1

        # print(str(high)+','+str(low))
        while (high - low) / theta > 1:
            #        print(imgobj.q,end=";")
            mid = (high + low) / 2.0
            mid_image = self.project(imgobj.img, perturbed_image, mid)
            d = imgobj.decision(mid_image)
            if d == 1:
                high = mid
            else:
                low = mid
            # print(str(high)+','+str(low))

        output = self.project(imgobj.img, perturbed_image, high)

        if l == 'l2':
            finaldist = self.norm(output, imgobj.img)[0]
        else:
            finaldist = self.norm(output, imgobj.img)[1]

        # print(theta)
        if l == 'l2':
            out_image = output.numpy()
        else:
            out_image = output
        return out_image, finaldist

    def norm(self, image, image2):
        if isinstance(image, np.ndarray):
            y = image
        else:
            y = image.numpy()[0]
        if isinstance(image2, np.ndarray):
            z = image2
        else:
            z = image2.numpy()[0]

        l2norm = np.linalg.norm(np.subtract(z, y).reshape(-1), ord=2)
        infnorm = np.linalg.norm(np.subtract(z, y).reshape(-1), ord=np.inf)
        return l2norm, infnorm

    def project(self, original_image, perturbed_images, alphas):

        return (1 - alphas) * original_image + alphas * perturbed_images

    def create_distorted_image(self, image, typ, epsilon, parameters):
        parameters = parameters[0]
        if typ == 'perlin':
            pert = self.perlin_noise(parameters[0], parameters[1], parameters[2])
        elif typ == 'gabor':
            pert = self.gabor_noise_random(int(parameters[0]), int(parameters[1]), parameters[2], parameters[3],
                                      parameters[4],
                                      sides=int(parameters[5]))
        elif typ == 'BICU' or typ == 'CLUSTER' or typ == 'NN' or typ == 'BILI':
            parameters = np.expand_dims(parameters, axis=0)
            pert = upsample_projection(typ, parameters, 16, self.imagesize * self.imagesize, nchannel=3)
            # pert = np.repeat(pert,3,axis=0)
            pert = pert.reshape(1, 3, self.imagesize, self.imagesize)
            pert = pert.transpose(0, 2, 3, 1)
            pert = (pert - np.min(pert)) / np.ptp(pert)

        pert = (pert - .5) * 2
        # print(str(np.max(pert))+','+str(np.min(pert)))
        dist_img = image + epsilon * pert
        return dist_img

    def perlin_noise(self, noise_scale, noise_octaves, color_freq, noise_p=1, noise_l=2):
        blank = np.zeros((self.imagesize, self.imagesize, 3))
        for i in range(self.imagesize):
            for j in range(self.imagesize):
                for k in range(3):
                    blank[i][j][k] = .5 + ns.pnoise2(i / int(noise_scale),
                                                     j / int(noise_scale),
                                                     octaves=int(noise_octaves),
                                                     persistence=float(noise_p),
                                                     lacunarity=float(noise_l),
                                                     repeatx=self.imagesize,
                                                     repeaty=self.imagesize,
                                                     base=0
                                                     )
        blank = np.sin(blank * color_freq * np.pi)
        if self.dataset == 'MNIST':
            blank = np.expand_dims(self.rgb2gray(blank), -1)
            # print(blank.shape)
        return self.normalize(blank)

    def rgb2gray(self, rgb):
        gray = np.mean(rgb, -1)

        return gray

    def normalize(self, vec):
        vmax = np.amax(vec)
        vmin = np.amin(vec)
        return (vec - vmin) / (vmax - vmin)

    def gabor_noise_random(self, num_kern, ksize, sigma, theta, lambd, xy_ratio=1, sides=1, seed=0):
        grid = 20
        np.random.seed(seed)

        # Gabor kernel
        if sides != 1:
            gabor_kern = self.gaborK(ksize, sigma, theta, lambd, xy_ratio, sides)
        else:
            gabor_kern = cv2.getGaborKernel((ksize, ksize), sigma, theta, lambd, xy_ratio, 0, ktype=cv2.CV_32F)

        # Sparse convolution noise
        sp_conv = np.zeros([self.imagesize, self.imagesize])
        dim = int(self.imagesize / 2 // grid)
        noise = []
        for i in range(-dim, dim + 1):
            for j in range(-dim, dim + 1):
                x = i * grid + self.imagesize / 2 - grid / 2
                y = j * grid + self.imagesize / 2 - grid / 2
                for _ in range(num_kern):
                    dx = np.random.randint(0, grid)
                    dy = np.random.randint(0, grid)
                    while not self.valid_position(self.imagesize, x + dx, y + dy):
                        dx = np.random.randint(0, grid)
                        dy = np.random.randint(0, grid)
                    weight = np.random.random() * 2 - 1
                    sp_conv[int(x + dx)][int(y + dy)] = weight

        sp_conv = cv2.filter2D(sp_conv, -1, gabor_kern)

        normn = self.normalize(sp_conv)
        normn = np.around(normn)
        normn = np.expand_dims(normn, 0)
        if self.dataset == 'MNIST':
            return np.expand_dims(normn, -1)
        else:
            normn = np.expand_dims(normn, 3)
            normn = tf.image.grayscale_to_rgb(tf.convert_to_tensor(normn))

        return normn.numpy()

    def gaborK(self, ksize, sigma, theta, lambd, xy_ratio, sides):
        gabor_kern = cv2.getGaborKernel((int(ksize), int(ksize)), sigma, theta, lambd, xy_ratio, 0, ktype=cv2.CV_32F)
        for i in range(1, int(sides)):
            gabor_kern += cv2.getGaborKernel((ksize, ksize), sigma, theta + np.pi * i / sides, lambd, xy_ratio, 0,
                                             ktype=cv2.CV_32F)
        return gabor_kern

    def valid_position(self, size, x, y):
        if x < 0 or x >= size: return False
        if y < 0 or y >= size: return False
        return True

class BODBA(object):
    def __init__(self, model, dataset, clip_min, clip_max, height, width, channels, norm, epsilon, load_random_class_image,
                 maximum_queries=10000, batch_size=1):
        """
        :param clip_min: lower bound of the image.
        :param clip_max: upper bound of the image.
        :param norm: choose between [l2, linf].
        :param iterations: number of iterations.
        :param gamma: used to set binary search threshold theta. The binary search
                     threshold theta is gamma / d^{3/2} for l2 attack and gamma / d^2 for linf attack.
        :param max_num_evals: maximum number of evaluations for estimating gradient.
        :param init_num_evals: initial number of evaluations for estimating gradient.
        """
        self.model = model
        self.norm = norm
        self.ord = np.inf if self.norm == "linf" else 2
        self.epsilon = epsilon
        self.clip_min = clip_min
        self.clip_max = clip_max
        self.height = height
        self.width = width
        self.channels = channels
        self.shape = (channels, height, width)
        self.dim = np.prod(self.shape)
        self.load_random_class_image = load_random_class_image

        self.maximum_queries = maximum_queries
        self.dataset_name = dataset
        self.dataset_loader = DataLoaderMaker.get_test_attacked_data(dataset, batch_size)
        self.batch_size = batch_size
        self.total_images = len(self.dataset_loader.dataset)
        self.query_all = torch.zeros(self.total_images) # query times
        self.distortion_all = defaultdict(OrderedDict)  # key is image index, value is {query: distortion}
        self.correct_all = torch.zeros_like(self.query_all)  # number of images
        self.not_done_all = torch.zeros_like(self.query_all)  # always set to 0 if the original image is misclassified
        self.success_all = torch.zeros_like(self.query_all)
        self.success_query_all = torch.zeros_like(self.query_all)
        self.distortion_with_max_queries_all = torch.zeros_like(self.query_all)

    def decision_function(self, images, true_labels, target_labels):
        images = torch.clamp(images, min=self.clip_min, max=self.clip_max)
        logits = self.model(images)
        if target_labels is None:
            return logits.max(1)[1] != true_labels[0]
        else:
            return logits.max(1)[1] == target_labels[0]

    def initialize(self, sample, target_images, true_labels, target_labels):
        """
        sample: the shape of sample is [C,H,W] without batch-size
        Efficient Implementation of BlendedUniformNoiseAttack in Foolbox.
        """
        num_eval = 0
        if target_images is None:
            while True:
                random_noise = torch.from_numpy(np.random.uniform(self.clip_min, self.clip_max, size=self.shape)).float().cuda()
                # random_noise = torch.FloatTensor(*self.shape).uniform_(self.clip_min, self.clip_max)
                success = self.decision_function(random_noise[None], true_labels, target_labels)
                num_eval += 1
                if success:
                    break
                if num_eval > 1000:
                    log.info("Initialization failed! Use a misclassified image as `target_image")
                    if target_labels is None:
                        target_labels = torch.randint(low=0, high=CLASS_NUM[self.dataset_name],
                                                      size=true_labels.size()).long().cuda()
                        invalid_target_index = target_labels.eq(true_labels)
                        while invalid_target_index.sum().item() > 0:
                            target_labels[invalid_target_index] = torch.randint(low=0, high=CLASS_NUM[self.dataset_name],
                                                                size=target_labels[invalid_target_index].size()).long().cuda()
                            invalid_target_index = target_labels.eq(true_labels)

                    initialization = select_random_image_of_target_class(self.dataset_name, target_labels, self.model, self.load_random_class_image).squeeze()
                    return initialization, 1
                # assert num_eval < 1e4, "Initialization failed! Use a misclassified image as `target_image`"
            # Binary search to minimize l2 distance to original image.
            low = 0.0
            high = 1.0
            while high - low > 0.001:
                mid = (high + low) / 2.0
                blended = (1 - mid) * sample + mid * random_noise
                success = self.decision_function(blended, true_labels, target_labels)
                num_eval += 1
                if success:
                    high = mid
                else:
                    low = mid
            # Sometimes, the found `high` is so tiny that the difference between initialization and sample is very
            # small, this case will cause an infinity loop
            initialization = (1 - high) * sample + high * random_noise
        else:
            initialization = target_images
        return initialization, num_eval

    def bayesian_attack(self, image, init_query=5, noise='perlin', max_norm=16, constraint='l2'):

        if noise == 'perlin':
            bounds = [{'name': 'wavelength', 'type': 'continuous', 'domain': (10, 200), 'dimensionality': 1},
                      {'name': 'octave', 'type': 'discrete', 'domain': (1, 2, 3, 4), 'dimensionality': 1},
                      {'name': 'freq_sine', 'type': 'continuous', 'domain': (4, 32), 'dimensionality': 1}
                      ]
        elif noise == 'gabor':
            bounds = [{'name': 'kernels', 'type': 'discrete', 'domain': (1, 200), 'dimensionality': 1},
                      {'name': 'kernel size', 'type': 'discrete', 'domain': (1, 40), 'dimensionality': 1},
                      {'name': 'sigma', 'type': 'continuous', 'domain': (1, 8), 'dimensionality': 1},
                      {'name': 'orientation', 'type': 'continuous', 'domain': (0, 2 * np.pi), 'dimensionality': 1},
                      {'name': 'scale', 'type': 'continuous', 'domain': (1, 20), 'dimensionality': 1},
                      {'name': 'sides', 'type': 'discrete', 'domain': (1, 12), 'dimensionality': 1}
                      ]
        else:
            bounds = [{'name': 'wavelength', 'type': 'continuous', 'domain': (-1, 1), 'dimensionality': 48}]

        feasible_space = gy.Design_space(space=bounds)
        initial_design = gy.experiment_design.initial_design('random', feasible_space, init_query)

        queries = 0

        optimized = preddifference(image, self.dataset_name, max_norm, noise=noise, constraint=constraint)

        # Gaussian process and Bayesian optimization
        objective = gy.core.task.SingleObjective(optimized.func, num_cores=1)
        model = gy.models.GPModel(exact_feval=False, optimize_restarts=5, verbose=False)
        aquisition_opt = gy.optimization.AcquisitionOptimizer(feasible_space)
        acquisition = gy.acquisitions.AcquisitionEI(model, feasible_space, optimizer=aquisition_opt)
        evaluator = gy.core.evaluators.Sequential(acquisition, batch_size=1)
        BOpt = gy.methods.ModularBayesianOptimization(model, feasible_space, objective, acquisition, evaluator,
                                                      initial_design)

        TimeHistory = [[0, 0]]
        t1 = millis()
        last = 0
        t = tqdm(total=self.maximum_queries)
        quitcount = 0
        while image.query < self.maximum_queries:
            BOpt.run_optimization(max_iter=1)
            t.n = image.query
            t.update(n=0)
            if image.query == last:
                quitcount = quitcount + 1
                if quitcount < 5:
                    print('===============')
                    continue
                else:
                    break
            else:
                last = image.query
            t2 = millis()
            TimeHistory.append([image.query, t2 - t1])
        return TimeHistory, optimized.adv

    def attack(self, batch_index, images, target_images, true_labels, target_labels):
        self.query = torch.zeros_like(true_labels).float()
        success_stop_queries = self.query.clone()  # stop query count once the distortion < epsilon
        batch_image_positions = np.arange(batch_index * self.batch_size,
                                          min((batch_index + 1)*self.batch_size, self.total_images)).tolist()
        batch_size = images.size(0)

        x = randomimg(images.permute(0, 2, 3, 1), self.model, true_labels.cuda(), target_labels)
        # y = true_labels.cuda()
        # x_adv, num_eval = self.initialize(images.cuda(), target_images, y, target_labels)
        timehistory, adversarial = self.bayesian_attack(x, noise='NN', constraint=self.norm, init_query=5)
        print(timehistory)
        print(np.linalg.norm(np.subtract(images.numpy(), adversarial.transpose(0, 3, 1, 2)).reshape(-1), ord=2))
        exit()
        return 0
        # return x_adv, query, success_stop_queries, dist, (dist <= self.epsilon)

    def attack_all_images(self, args, arch_name, result_dump_path):
        if args.targeted and args.target_type == "load_random":
            loaded_target_labels = np.load("./target_class_labels/{}/label.npy".format(args.dataset))
            loaded_target_labels = torch.from_numpy(loaded_target_labels).long()
        for batch_index, (images, true_labels) in enumerate(self.dataset_loader):
            if batch_index < 1:
                continue
            if args.dataset == "ImageNet" and self.model.input_size[-1] != 299:
                images = F.interpolate(images,
                                       size=(self.model.input_size[-2], self.model.input_size[-1]), mode='bilinear',
                                       align_corners=False)
            with torch.no_grad():
                logit = self.model(images.cuda())
            pred = logit.argmax(dim=1)
            correct = pred.eq(true_labels.cuda()).float()  # shape = (batch_size,)
            if correct.int().item() == 0: # we must skip any image that is classified incorrectly before attacking, otherwise this will cause infinity loop in later procedure
                log.info("{}-th original image is classified incorrectly, skip!".format(batch_index+1))
                continue
            selected = torch.arange(batch_index * args.batch_size, min((batch_index + 1) * args.batch_size, self.total_images))
            if args.targeted:
                if args.target_type == 'random':
                    target_labels = torch.randint(low=0, high=CLASS_NUM[args.dataset],
                                                  size=true_labels.size()).long()
                    invalid_target_index = target_labels.eq(true_labels)
                    while invalid_target_index.sum().item() > 0:
                        target_labels[invalid_target_index] = torch.randint(low=0, high=logit.shape[1],
                                                                            size=target_labels[invalid_target_index].shape).long()
                        invalid_target_index = target_labels.eq(true_labels)
                elif args.target_type == "load_random":
                    target_labels = loaded_target_labels[selected]
                    assert target_labels[0].item()!=true_labels[0].item()
                    # log.info("load random label as {}".format(target_labels))
                elif args.target_type == 'least_likely':
                    target_labels = logit.argmin(dim=1).detach().cpu()
                elif args.target_type == "increment":
                    target_labels = torch.fmod(true_labels + 1, CLASS_NUM[args.dataset])
                else:
                    raise NotImplementedError('Unknown target_type: {}'.format(args.target_type))

                target_images = select_random_image_of_target_class(self.dataset_name, target_labels, self.model, self.load_random_class_image)
                if target_images is None:
                    log.info("{}-th image cannot get a valid target class image to initialize!".format(batch_index+1))
                    continue
            else:
                target_labels = None
                target_images = None

            adv_images, query, success_query, distortion_with_max_queries, success_epsilon = self.attack(batch_index, images, target_images, true_labels, target_labels)
            distortion_with_max_queries = distortion_with_max_queries.detach().cpu()
            with torch.no_grad():
                if adv_images.dim() == 3:
                    adv_images = adv_images.unsqueeze(0)
                adv_logit = self.model(adv_images.cuda())
            adv_pred = adv_logit.argmax(dim=1)
            ## Continue query count
            not_done = correct.clone()
            if args.targeted:
                not_done = not_done * (1 - adv_pred.eq(target_labels.cuda()).float()).float()  # not_done��ʼ��Ϊ correct, shape = (batch_size,)
            else:
                not_done = not_done * adv_pred.eq(true_labels.cuda()).float()  #
            success = (1 - not_done.detach().cpu()) * correct.detach().cpu() * success_epsilon.detach().cpu() * (
                        success_query.detach().cpu() <= self.maximum_queries).float()

            for key in ['query', 'correct', 'not_done',
                        'success', 'success_query', "distortion_with_max_queries"]:
                value_all = getattr(self, key + "_all")
                value = eval(key)
                value_all[selected] = value.detach().float().cpu()

        log.info('{} is attacked finished ({} images)'.format(arch_name, self.total_images))
        log.info('Saving results to {}'.format(result_dump_path))
        meta_info_dict = {"avg_correct": self.correct_all.mean().item(),
                          "avg_not_done": self.not_done_all[self.correct_all.bool()].mean().item(),
                          "mean_query": self.success_query_all[self.success_all.bool()].mean().item() if self.success_all.sum().item() > 0 else 0,
                          "median_query": self.success_query_all[self.success_all.bool()].median().item() if self.success_all.sum().item() > 0 else 0,
                          "max_query": self.success_query_all[self.success_all.bool()].max().item() if self.success_all.sum().item() > 0 else 0,
                          "correct_all": self.correct_all.detach().cpu().numpy().astype(np.int32).tolist(),
                          "not_done_all": self.not_done_all.detach().cpu().numpy().astype(np.int32).tolist(),
                          "success_all":self.success_all.detach().cpu().numpy().astype(np.int32).tolist(),
                          "query_all": self.query_all.detach().cpu().numpy().astype(np.int32).tolist(),
                          "success_query_all": self.success_query_all.detach().cpu().numpy().astype(np.int32).tolist(),
                          "distortion": self.distortion_all,
                          "avg_distortion_with_max_queries": self.distortion_with_max_queries_all.mean().item(),
                          "args": vars(args)}
        with open(result_dump_path, "w") as result_file_obj:
            json.dump(meta_info_dict, result_file_obj, sort_keys=True)
        log.info("done, write stats info to {}".format(result_dump_path))


def get_exp_dir_name(dataset,  norm, targeted, target_type, args):
    if target_type == "load_random":
        target_type = "random"
    target_str = "untargeted" if not targeted else "targeted_{}".format(target_type)
    if args.attack_defense:
        dirname = 'Evolutionary_on_defensive_model-{}-{}-{}'.format(dataset, norm, target_str)
    else:
        dirname = 'Evolutionary-{}-{}-{}'.format(dataset, norm, target_str)
    return dirname

def print_args(args):
    keys = sorted(vars(args).keys())
    max_len = max([len(key) for key in keys])
    for key in keys:
        prefix = ' ' * (max_len + 1 - len(key)) + key
        log.info('{:s}: {}'.format(prefix, args.__getattribute__(key)))

def set_log_file(fname):
    import subprocess
    tee = subprocess.Popen(['tee', fname], stdin=subprocess.PIPE)
    os.dup2(tee.stdin.fileno(), sys.stdout.fileno())
    os.dup2(tee.stdin.fileno(), sys.stderr.fileno())

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu",type=int, required=True)
    parser.add_argument('--json-config', type=str, default='../configures/Evolutionary.json',
                        help='a configures file to be passed in instead of arguments')
    parser.add_argument('--epsilon', type=float, help='the lp perturbation bound')
    parser.add_argument("--norm",type=str, choices=["l2","linf"],required=True)
    parser.add_argument('--batch-size', type=int, default=1, help='batch size must set to 1')
    parser.add_argument('--dataset', type=str, required=True,
               choices=['CIFAR-10', 'CIFAR-100', 'ImageNet', "FashionMNIST", "MNIST", "TinyImageNet"], help='which dataset to use')
    parser.add_argument('--arch', default=None, type=str, help='network architecture')
    parser.add_argument('--all-archs', action="store_true")
    parser.add_argument('--targeted', action="store_true")
    parser.add_argument('--target-type', type=str, default='increment', choices=['random', "load_random", 'least_likely',"increment"])
    parser.add_argument('--load-random-class-image', action='store_true',
                        help='load a random image from the target class')  # npz {"0":, "1": ,"2": }
    parser.add_argument('--exp-dir', default='logs', type=str, help='directory to save results and logs')
    parser.add_argument('--seed', default=0, type=int, help='random seed')
    parser.add_argument('--attack_defense',action="store_true")
    parser.add_argument('--defense_model',type=str, default=None)
    parser.add_argument('--defense_norm',type=str,choices=["l2","linf"],default='linf')
    parser.add_argument('--defense_eps',type=str,default="")
    parser.add_argument('--k', type=int, help='the key parameter that influences the results of untargeted and targeted attacks')
    parser.add_argument('--max-queries',type=int, default=10000)

    args = parser.parse_args()
    assert args.batch_size == 1, "Evolutionary Attack only supports mini-batch size equals 1!"
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)
    args_dict = None
    if not args.json_config:
        # If there is no json file, all of the args must be given
        args_dict = vars(args)
    else:
        # If a json file is given, use the JSON file as the base, and then update it with args
        defaults = json.load(open(args.json_config))[args.dataset][args.norm]
        arg_vars = vars(args)
        arg_vars = {k: arg_vars[k] for k in arg_vars if arg_vars[k] is not None}
        defaults.update(arg_vars)
        args = SimpleNamespace(**defaults)
        args_dict = defaults
    if args.targeted:
        if args.dataset == "ImageNet":
            args.max_queries = 20000
    if args.attack_defense and args.defense_model == "adv_train_on_ImageNet":
        args.max_queries = 20000
    args.exp_dir = osp.join(args.exp_dir,
                            get_exp_dir_name(args.dataset, args.norm, args.targeted, args.target_type, args))
    os.makedirs(args.exp_dir, exist_ok=True)

    if args.all_archs:
        if args.attack_defense:
            log_file_path = osp.join(args.exp_dir, 'run_defense_{}.log'.format(args.defense_model))
        else:
            log_file_path = osp.join(args.exp_dir, 'run.log')
    elif args.arch is not None:
        if args.attack_defense:
            if args.defense_model == "adv_train_on_ImageNet":
                log_file_path = osp.join(args.exp_dir,
                                         "run_defense_{}_{}_{}_{}.log".format(args.arch, args.defense_model,
                                                                              args.defense_norm,
                                                                              args.defense_eps))
            else:
                log_file_path = osp.join(args.exp_dir, 'run_defense_{}_{}.log'.format(args.arch, args.defense_model))
        else:
            log_file_path = osp.join(args.exp_dir, 'run_{}.log'.format(args.arch))
    set_log_file(log_file_path)
    if args.attack_defense:
        assert args.defense_model is not None

    torch.backends.cudnn.deterministic = True
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if args.all_archs:
        archs = MODELS_TEST_STANDARD[args.dataset]
    else:
        assert args.arch is not None
        archs = [args.arch]
    args.arch = ", ".join(archs)
    log.info('Command line is: {}'.format(' '.join(sys.argv)))
    log.info("Log file is written in {}".format(log_file_path))
    log.info('Called with args:')
    print_args(args)
    for arch in archs:
        if args.attack_defense:
            if args.defense_model == "adv_train_on_ImageNet":
                save_result_path = args.exp_dir + "/{}_{}_{}_{}_result.json".format(arch, args.defense_model,
                                                                                    args.defense_norm,args.defense_eps)
            else:
                save_result_path = args.exp_dir + "/{}_{}_result.json".format(arch, args.defense_model)
        else:
            save_result_path = args.exp_dir + "/{}_result.json".format(arch)
        if os.path.exists(save_result_path):
            continue
        log.info("Begin attack {} on {}, result will be saved to {}".format(arch, args.dataset, save_result_path))
        if args.attack_defense:
            model = DefensiveModel(args.dataset, arch, no_grad=True, defense_model=args.defense_model,
                                   norm=args.defense_norm, eps=args.defense_eps)
        else:
            model = StandardModel(args.dataset, arch, no_grad=True)
        model.cuda()
        model.eval()
        attacker = BODBA(model, args.dataset, 0, 1.0, model.input_size[-2], model.input_size[-1], IN_CHANNELS[args.dataset],
                                args.norm, args.epsilon, args.load_random_class_image,
                                maximum_queries=args.max_queries, batch_size=args.batch_size)
        attacker.attack_all_images(args, arch, save_result_path)
        model.cpu()
